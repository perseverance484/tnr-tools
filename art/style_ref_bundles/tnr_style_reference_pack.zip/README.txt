TNR visual reference pack - operator transfer bundle
====================================================

Built by skills/producing-tnr-art/scripts/style_refs.py bundle from the provenance-checked
reference pack (tnr.style_refs v1, capture push/03_tnr_art_style_reference_capture.json -> harvests/inbox/tnr_results_1789061570022.json, 18 reads, 0 mutations).
Selection: full pack (18 references).

WHAT THIS IS
  The exact individual reference images, byte for byte, plus style_refs.json, so an
  operator can download one file to a phone, extract it once, and later attach
  exactly the individual images a session names.

WHAT THIS IS NOT
  - Uploading this ZIP to a conversation is NOT reference hydration. A ZIP is not a
    rendered image; nothing in it has been looked at.
  - It is not a collage or contact sheet and must never be turned into one for a
    generator: multiple subjects in one frame get blended.
  - It is not art doctrine. 25x_DATA_art_spec.json governs; these calibrate.

HOW TO HYDRATE A SESSION
  1. The session's generation preflight names the selected reference keys.
  2. Attach those individual image files, each one separately, so they render as
     images in the conversation.
  3. The assistant looks at each one and says what it saw. Only then may the
     reference mode be declared ATTACHED (the generator has the images) or
     ASSISTANT_GROUNDED (the assistant saw them; the generator cannot take images
     and the session must say so).
  Paths, URLs, hashes or unrendered base64 alone are NOT_HYDRATED: generation stops.

MEMBERS  (arcname | sha256 | bytes | key | name | target/register)
  scene_backgrounds/canal_frontage.webp | 5bb8fb68472dbf25a4dc400fa1617c6149642afd7dd7700d1fb94004e022a076 | 128742 | canal_frontage | Forsworn Scene BG - Canal Frontage | SCENE_BACKGROUND
  scene_backgrounds/drying_shed.webp | e4a8b721cc5c30dda031bbf77def948b159660bbcf0852d758727e7c0cd1bee9 | 69802 | drying_shed | Forsworn Scene BG - Drying Shed | SCENE_BACKGROUND
  scene_backgrounds/drying_yard.webp | 68a6ae61b27be28d1760f80bb35661ece858d2570f1cfed76594f06bd2af94ab | 107652 | drying_yard | Forsworn Scene BG - Drying Yard | SCENE_BACKGROUND
  scene_backgrounds/east_road_ambush_site.webp | 59fda90c3df9a2c8b28706c784258be9faa82bb8f8c07c73b4d72d689fbae0ec | 109878 | east_road_ambush_site | Forsworn Scene BG - East Road Ambush Site | SCENE_BACKGROUND
  scene_backgrounds/pass_road_dusk.webp | 58f83e7c11ccce2ba49021f11676c8d7612c11718637cc8fded15d6b4a451c7a | 88824 | pass_road_dusk | Forsworn Scene BG - Pass Road Dusk | SCENE_BACKGROUND
  scene_backgrounds/rooftop_eastern_quarter.webp | f8656663ebe75747a19a188236eb45211319a4e479808a4cea9183168f8c82b3 | 124960 | rooftop_eastern_quarter | Forsworn Scene BG - Rooftop Eastern Quarter | SCENE_BACKGROUND
  scene_backgrounds/warehouse_loading_floor.webp | b8875df27ade0684b806bc5858de07ee3f5e1544b1317245a90970d1e8899053 | 174132 | warehouse_loading_floor | Forsworn Scene BG - Warehouse Loading Floor | SCENE_BACKGROUND
  scene_backgrounds/waystation_door.webp | 3550fed4bd3835194b75d939ab359431982c0269a0223fec12a842066f606320 | 122230 | waystation_door | Forsworn Scene BG - Waystation Door | SCENE_BACKGROUND
  scene_characters/commander_okabe.png | 8799456bf0a47278c6fad147d57de7e4f27c2e3058a377c839a53189c1ea82d4 | 104825 | commander_okabe | Commander Okabe | SCENE_CHARACTER/NINJA
      LIMIT: NOT the framing/aspect target and NOT the alpha-edge quality target. It is square rather than the full-body scene-character framing, and the art spec records it as the weakest exemplar of the ratified set on soft-edge share. Take framing, silhouette and edge quality from the Forsworn references instead.
  scene_characters/deputy.webp | 8da0ba479fa75267048a6243b02ee48bdcbe647fbb34cb51a95acbf8479fb35e | 121918 | deputy | Forsworn Scene - Deputy | SCENE_CHARACTER/CIVILIAN
  scene_characters/grain_merchant.webp | 7cce6051d14561b9d4dd7690cb2cee7b3128ec03d8945e50958446b481c08cf0 | 117070 | grain_merchant | Forsworn Scene - Grain Merchant | SCENE_CHARACTER/CIVILIAN
  scene_characters/keeper.webp | b757443069119ec3355493dd87d3a0be44bf55a6e3aec0c46093a26839a25741 | 117316 | keeper | Forsworn Scene - Keeper | SCENE_CHARACTER/CIVILIAN
  scene_characters/old_ghost.webp | 50b229e06d1897e63ef2e9a8f84f3bd917f236de88786c42d49d9008d53d3e7b | 118782 | old_ghost | Forsworn Scene - Old Ghost | SCENE_CHARACTER/NINJA
  scene_characters/pale_fang.webp | a47261605c9973895a88d9d62b4f7fb64a802445699b738f200288941aabfc76 | 83094 | pale_fang | Forsworn Scene - Pale Fang | SCENE_CHARACTER/NINJA
  scene_characters/principal.webp | a6badababde4394bc099704cab9dbd678b2b96adf1e453d797a93b63c7a1929f | 354086 | principal | Forsworn Scene - Principal | SCENE_CHARACTER/CIVILIAN
  scene_characters/squad_survivor.webp | 3144fca42b7e6ccce38b19559814d4adcc6c8318c266311472b801525a6def7a | 79696 | squad_survivor | Forsworn Scene - Squad Survivor | SCENE_CHARACTER/NINJA
  scene_characters/warehouse_clerk.webp | b5497b1cfe83b9e0a23196050740ed73c8e43bcbfac6894cfbc4d8b9079a4fe7 | 104984 | warehouse_clerk | Forsworn Scene - Warehouse Clerk | SCENE_CHARACTER/CIVILIAN
  scene_characters/winter_crow.webp | 42088c604a5a482fe9e3bbe0f0ac4b99117163a547196ca65b88616b9b3e3d56 | 95342 | winter_crow | Forsworn Scene - Winter Crow | SCENE_CHARACTER/NINJA
  style_refs.json | a356c6d2d75f96a1cf82c38f2e4948dec8031ffb0b80f599b2026417551344a9 | (index)
  MANIFEST.json | (generated; the same members as JSON)

Hashes are SHA-256 over the exact file bytes and match style_refs.json.
